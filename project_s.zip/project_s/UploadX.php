<?php
session_start();
	//connect to data base 
	require 'databaseConn.php';
	
	
	// requires php5
	define('UPLOAD_DIR', 'images/');
	$img = $_POST['image'];
	$x=$img;
	$img = str_replace('data:image/png;base64,', '', $img);
	$img = str_replace(' ', '+', $img);
	$data = base64_decode($img);
	$file = UPLOAD_DIR . uniqid() . '.png';

	$success = file_put_contents($file, $data);
	 $success ? $file : 'Unable to save the file.';
				$email=$_SESSION['email'];
		$productPrice = $_POST['price'];
  //$ProductImage = file_get_contents($file);
  $ProductImage = addslashes(file_get_contents($file));
	$statement = "insert into product(price,image,added_by) values ('$productPrice','$ProductImage','$email')";
if(!$result = mysqli_query($conn,$statement))
			{
				//echo "problem";
				mysqli_error($conn);
			}
			else
			{
			//	echo $productImagexx;
				//echo " dhuke";
				header('location:design.php');
			}
?>